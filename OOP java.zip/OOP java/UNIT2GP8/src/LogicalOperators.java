import java.util.Scanner;
public class LogicalOperators 
{

	public static void main(String[] args) 
	{
	// create truth table for && (conditional AND) operator
	System.out.printf("%s%n%s: %b%n%s: %b%n%s: %b%n%s: %b%n%n",
	   "Conditional AND (&&)", "false && false", (false && false)  ,
	   "false && true", (false && true) ,
	   "true && false", (true && false) ,
	   "true && true", (true && true) );
					
	// create truth table for || (conditional OR) operator
	System.out.printf("%s%n%s: %b%n%s: %b%n%s: %b%n%s: %b%n%n", 
	   "Conditional OR (||)", "false || false", (false || false) ,
	   "false || true", (false || true) ,
	   "true || false", (true || false) ,
	   "true || true", (true || true) );
		   
    // create truth table for & (boolean logical AND) operator
    System.out.printf("%s%n%s: %b%n%s: %b%n%s: %b%n%s: %b%n%n", 
       "Boolean logical AND (&)", "false & false", (false & false) ,
       "false & true", (false & true) ,
       "true & false", (true & false) ,
       "true & false", (true & true) ) ;
										
    // create truth table for | (boolean logical inclusive OR) operator
    System.out.printf("%s%n%s: %b%n%s: %b%n%s: %b%n%s: %b%n%n", 
       "Boolean logical inclusive OR (|)",
       "false | false", (false | false) ,
       "false | true", (false | true) ,
       "true | false", (true | false) ,
       "true | true", (true | true) );
    
    // create truth table for ^ (boolean logical exclusive OR) operator
    System.out.printf("%s%n%s: %b%n%s: %b%n%s: %b%n%s: %b%n%n", 
       "Boolean logical exclusive OR (^)",
       "false ^ false", (false ^ false) ,
       "false ^ true", (false ^ true) ,
       "true ^ false", (true ^ false) ,
       "true ^ true", (true ^ true) ) ;
    
    // create truth table for ! (logical negation) operator
    System.out.printf("%s%n%s: %b%n%s: %b%n",  "Logical NOT (!)",
       "!false", (!false) , "!true", (!true) );
    
    
    int total = 0;
    int gradeCounter =0;
	int aCount = 0;
	int bCount = 0;
	int cCount = 0;
	int dCount = 0;
	int fCount = 0;
    
	Scanner input = new Scanner(System.in);

     // if user entered at least one grade...
     if (gradeCounter != 0)
    {
    	// calculate average of all grades entered
    	double average = (double) total / gradeCounter;
    	
    	// output summary of results
    	System.out.printf("Total of the %d grades entered is %d%n",
    	   gradeCounter, total);
    	System.out.printf("Class average is %.2f%n", average);
    	System.out.printf("%n%s%n%s%d%n%s%d%n%s%d%n%s%d%n%s%d%n",
    	   "Number of students who received each grade:",
    	   "A: ", aCount = 0,  // display number of A grades
    	   "B: ", bCount = 0,  // display number of B grades
    	   "C: ", cCount = 0,  // display number of C grades
    	   "D: ", dCount = 0,  // display number of D grades
    	   "F: ", fCount = 0);  // display number of F grades
    	
    	
     } // end if
    else // no grades were entered, so output appropriate message
    	System.out.println("No grades were entered");
    } // end main
  } // end class LetterGrades
    			

