
public class BasePlusCommissionEmployeeTest
{

	public static void main(String[] args)
	{
		BasePlusCommissionEmployee employee =
				new BasePlusCommissionEmployee(
						"Bob", "Lewis", "333-33-3333", 5000, .04, 300);
		
		System.out.println(
				"Employee information obtained by get methods:");
		System.out.printf("%s %s%n", "First name is",
				employee.getFirstName());
		System.out.printf("%s %s%n", "Last name is",
				employee.getLastName());
		System.out.printf("%s %s%n", "Social security number name is",
				employee.getSocialSecurityNumber());
		System.out.printf("%s %.2f%n", "Gross sales is",
				employee.getGrossSales());
		System.out.printf("%s %.2f%n", "Commission rate is",
				employee.getCommissionRate());
		System.out.printf("%s %.2f%n", "Base salary is",
				employee.getBaseSalary());
		
		employee.setBaseSalary(1000);
		
		System.out.printf("%n%s:%n%n%s%n", 
				"Updated employee information obtained by toString",
				employee.toString());
		

	}// end main




     public String getSocialSecurityNumber()
     {
    	 return socialSecurityNumber;
     }
     
     public void setGrossSales(double grossSales)
     {
    	 if (grossSales < 0.0)
    		 throw new IllegalArgumentException(
     				"Gross sales must be >= 0.0");
    	 this.grossSales = grossSales;
     }
     
     public double getGrossSales()
     {
     	return grossSales;
     }
     
     public void setCommissionRate(double commissionRate)
     {
     	if (commissionRate <=0.0 || commissionRate >= 1.0)
     		throw new IllegalArgumentException(
     				"Commission rate must be > 0.0 and < 1.0");
     	
     	this.commissionRate = commissionRate;
     }
     
     public double getCommissionRate()
     {
     	return commissionRate;
     }
     
     public double earnings()
     {
    	 return commissionRate * grossSales;
     }
     
     @Override
     public String toString()
     {
     	return String.format("%s: %s %s%n%s: %s%n%s: %.2f%n%s: %.2f", 
     			"commission employee" , firstName, lastName,
     			"social security number" , socialSecurityNumber,
     			
     			"gross sales", grossSales,
     			"commission rate", commissionRate);
     		
     }
     
}// end class

