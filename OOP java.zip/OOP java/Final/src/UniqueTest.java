
public class UniqueTest {

	public static void main(String[] args)// we are now entering the deep abyass
	{
		UniqueTest1 application = new UniqueTest1();
		application.getNumbers();// get yo life

	}// end class

}// end main
