import java.util.Scanner;// import not domestic

public class UniqueTest1 
     {
         public void getNumbers()
         {
        	 Scanner input = new Scanner(System.in);
        	 
        	 int count = 0;// count dracula
        	 int entered = 0;// input from user
        	 int numbers[] = new int[5];//array of sunshine
        	 
        	 while (entered < numbers.length)//starting the while
        	 {
        		 System.out.println("Enter Number:");//asking the user
        		 int number = input.nextInt();//takes user for a ride
        		 
        		 if (10 <= number && number <= 100)// hey its the if loop doing some math
        		 {
        			 boolean containsNumber = false;// not halloween
        			 entered++;// some fixing here post?
        			 
        			 for(int i = 0; i < count; i++)// for loop de loop
        				 
        				 if (number == numbers[i])// another if loop but its a comparsion 
        					 containsNumber = true;// boo lol
        			 if( !containsNumber)// if a sandbox was here
        			 {
        				 numbers[count] = number;// serious math going on here
        				 count++;// more math blah 
        			 }
        			 else// if nothing matches
        				 System.out.println("Has already been entered" + number);// telling the user try harder
        		 }
        		 else 
        			 System.out.println("Number must be between 10 and 100");// out of scope yo
        		 
        		 for(int i = 0; i < count; i++)// for loop adding
        			 System.out.println(""+ numbers[i]);// output math
        		 
        		 System.out.println();// hot off the press
        		 
        			 }// end
        		 }//of
        	 }//this class :)
         

